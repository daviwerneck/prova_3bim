from database import db
from sqlalchemy import ForeignKey

class Cliente(db.Model):
    __tablename__ = 'cliente'
    id_cliente = db.Column(db.Integer, primary_key = True)
    nome = db.Column(db.String(100))
    telefone = db.Column(db.String(15))

    def __init__(self, nome, telefone):
        self.nome = nome
        self.telefone = telefone
    
    def __repr__(self):
        return "<Cliente {}>".format(self.nome)

class Reclamacao(db.Model):
    __tablename__ = 'reclamacao'
    id_reclamacao = db.Column(db.Integer, primary_key = True)
    descricao = db.Column(db.String(255))
    data = db.Column(db.Date)
    id_cliente = db.Column(db.Integer, db.ForeignKey('cliente.id_cliente'))

    cliente = db.relationship('Cliente', foreign_keys=id_cliente)

    def __init__(self, descricao, data, id_cliente):
        self.descricao = descricao
        self.data = data
        self.id_cliente = id_cliente

    def __repr__(self):
        return "<Reclamação {}>".format(self.descricao)
