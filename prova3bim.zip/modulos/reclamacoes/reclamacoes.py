from flask import Blueprint, render_template, request, redirect, flash
from models import Reclamacao, Cliente
from database import db

bp_reclamacao = Blueprint('reclamacoes', __name__, template_folder='templates')

@bp_reclamacao.route('/')
def index():
    r = Reclamacao.query.all()
    return render_template('reclamacao.html', reclamacoes = r)

@bp_reclamacao.route('/add')
def add():
    c = Cliente.query.all()
    return render_template('reclamacao_add.html', clientes = c)

@bp_reclamacao.route('/save', methods=['POST'])
def save():
    descricao = request.form.get('descricao')
    data = request.form.get('data')
    id_cliente = request.form.get('id_cliente')
    if descricao and data and id_cliente:
        bd_reclamacao = Reclamacao(descricao, data, id_cliente)
        db.session.add(bd_reclamacao)
        db.session.commit()
        flash('Salvo com sucesso!!!')
        return redirect('/reclamacoes')
    else:
        flash('Preencha todos os campos!!!')
        return redirect('/reclamacoes/add')

@bp_reclamacao.route('/remove/<int:id_reclamacao>')
def remove(id_reclamacao):
    dados = Reclamacao.query.get(id_reclamacao)
    if id_reclamacao > 0:
        db.session.delete(dados)
        db.session.commit()
        flash('Excluído com sucesso')
        return redirect('/reclamacoes')
    else:
        flash("Item não encontrado")
        return redirect("/reclamacoes")
